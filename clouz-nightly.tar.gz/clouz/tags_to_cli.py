#!/usr/bin/env python3

SWNAME="tags_to_cli.py"
SWVERS="1.0.15"
SWDATE="2021-11-27"
SWTIME="00:00:00"
SWDESC="generate cloud cli commands from tags in xlsx file"
SWTAGS="cloud,cli,tags,xlsx,excel,sqlite,mysql,python3"
SWCOPY="GPLv3"
SWAUTH="alexandre botao"
SWMAIL="alexandre at botao dot org"

###____________________________________________________________________________
###
###	tags	to	cli	cloud				2021'10 botao
###____________________________________________________________________________
###

import sys
import argparse
import openpyxl
import os
from os.path import exists
from csv import reader
from distutils.util import strtobool

###____________________________________________________________________________
###

def myversion():
	print("\n" + SWNAME + "   " + SWVERS + "   " + SWDATE + "\n")

###____________________________________________________________________________
###

def check_good_file(name):
	if exists(name):
		if os.path.isfile(name):
			return True
		else:
			print("path (%s) not file " % (name))
			exit()
	else:
		print("file (%s) not found" % (name))
		exit()

###____________________________________________________________________________
###	dump	csv
###____________________________________________________________________________

def dump_csv(csvreader):
	list_of_rows = list(csv_reader)
	print(list_of_rows)

###____________________________________________________________________________
###	list	csv
###____________________________________________________________________________

def list_csv(csvreader):
	line_count = 0
	for row in csv_reader:
		if line_count == 0:
			print(f'<head> {", ".join(row)}')
		else:
			print(f'<line> {line_count} {", ".join(row)}')
		line_count += 1
	### print(f'total {line_count} lines.')

###____________________________________________________________________________
###	list	worksheet
###____________________________________________________________________________

def list_worksheet(ws):
	""" list excel worksheet """
	if FORMAT == "html":
		print('<table border=1>')
		for i in range(0, ws.max_row):
			print('<tr>')
			print('<td>')
			print(ws.title)
			print('</td>')
			for col in ws.iter_cols(1, ws.max_column):
				print('<td>')
				print(col[i].value)
				print('</td>')
			print('</tr>')
		print('</table>')
	elif FORMAT == "cli":
		for i in range(0, ws.max_row):
			colnum = 1
			bud_amount = None
			bud_name = None
			bud_categ = None
			bud_start = None
			bud_end = None
			bud_grain = None
			bud_resgrp = None
			bud_subscr = None
			for col in ws.iter_cols(1, ws.max_column):
				# print(col[i].value, end=";")
				if colnum == 3:
					bud_name = col[i].value
				if colnum == 4:
					bud_categ = col[i].value
				if colnum == 5:
					bud_amount = col[i].value
				if colnum == 6:
					bud_start = col[i].value
				if colnum == 7:
					bud_end = col[i].value
				if colnum == 8:
					bud_grain = col[i].value
				if colnum == 9:
					bud_resgrp = col[i].value
				if colnum == 10:
					bud_subscr = col[i].value
				colnum += 1
			if CLOUDNAME == "az":
				if CLICMD == "create":
					if CLIARG == "budget":
						# az consumption budget create --amount aa --budget-name bb --category {cost, usage} --end-date ee --start-date ss --time-grain {annually, monthly, quarterly} --resource-group gg --subscription ss
						print('az consumption budget create --amount %s --budget-name "%s" --category "%s" --end-date "%s" --start-date "%s" --time-grain "%s" --resource-group "%s" --subscription "%s"' % (bud_amount,bud_name,bud_categ,bud_end,bud_start,bud_grain,bud_resgrp,bud_subscr))
			elif CLOUDNAME == "oci":
				if CLICMD == "create":
					if CLIARG == "budget":
						# oci budgets budget create --compartment-id $COMPARTMENT_ID --target-type $TARGET_TYPE --targets $TARGETS_JSON --amount $BUDGET_AMOUNT --reset-period MONTHLY
						print('oci budgets budget create --amount %s --display-name "%s" --compartment-id "%s" --target-type $TARGET_TYPE --targets $TARGETS_JSON --reset-period "%s"' % (bud_amount,bud_name,bud_resgrp,bud_grain))
					elif CLIARG == "alert":
						# oci budgets alert-rule create --budget-id $BUDGET_ID --type FORECAST --threshold 100 --threshold-type PERCENTAGE --recipients $ALERT_RULE_RECIPIENT
						print('    oci budgets alert-rule create --budget-id $BUDGET_ID --type FORECAST --threshold 100 --threshold-type PERCENTAGE --recipients $ALERT_RULE_RECIPIENT')
			elif CLOUDNAME == "gcp":
				# gcloud alpha billing budgets create --billing-account=BILLING_ACCOUNT --display-name=DISPLAY_NAME (--budget-amount=BUDGET_AMOUNT     | --last-period-amount) [--all-updates-rule-monitoring-notification-channels=[ALL_UPDATES_RULE_MONITORING_NOTIFICATION_CHANNELS,...]] [--all-updates-rule-pubsub-topic=ALL_UPDATES_RULE_PUBSUB_TOPIC] [--credit-types-treatment=CREDIT_TYPES_TREATMENT] [--disable-default-iam-recipients] [--filter-credit-types=[FILTER_CREDIT_TYPES,...]] [--filter-labels=FILTER_LABELS] [--filter-projects=[FILTER_PROJECTS,...]] [--filter-services=[FILTER_SERVICES,...]] [--filter-subaccounts=[FILTER_SUBACCOUNTS,...]] [--threshold-rule=THRESHOLD_RULE] [--calendar-period=CALENDAR_PERIOD     | [--start-date=START_DATE : --end-date=END_DATE]] [GCLOUD_WIDE_FLAG ...]
				print('gcloud alpha billing budgets create --billing-account="%s" --display-name="%s" --budget-amount=%s --start-date="%s" --end-date="%s"' % (bud_subscr,bud_name,bud_amount,bud_start,bud_end))
			else:
				print(">>> bad or undefined cloud")
			print('')
		print('')
	elif FORMAT == "csv":
		for i in range(0, ws.max_row):
			print(ws.title, end=";")
			for col in ws.iter_cols(1, ws.max_column):
				print(col[i].value, end=";")
			print('')
		print('')

###____________________________________________________________________________
###	dump	worksheet
###____________________________________________________________________________

def dump_worksheet(ws):
	""" dump excel worksheet """
	print('')
	print("============================================================")
	print("=== worksheet : " + ws.title)
	print("============================================================")
	### print (ws)
	for i in range(0, ws.max_row):
		print("=== line (%i)" % (1+i))
		for col in ws.iter_cols(1, ws.max_column):
			print(col[i].value, end=";")
		print('<eol>')
	print('<eows>')

###############################################################################
###	main
###############################################################################

if __name__ == "__main__":

	parser = argparse.ArgumentParser(description="""
	generate cloud cli commands from args or tags in xlsx/csv file. 
	""")
	###________________________________________________________________________
	###   args
	###________________________________________________________________________

	parser.add_argument("--csv",	 default="undef", help="csv file name")
	parser.add_argument("--xlsx",    default="undef", help="excel file name")
	parser.add_argument("--wsname",  default="undef", help="worksheet name")

	parser.add_argument("--cmd",	 default="undef", choices=["create", "delete", "list", "show"], help="cloud cli command")
	parser.add_argument("--arg",	 default="undef", choices=["account", "billingaccount", "budget", "alert", "usage"], help="cloud cli object")
	parser.add_argument("--format",	 default="csv", choices=["cli", "csv", "html", "json", "text", "xlsx"], help="output format")
	parser.add_argument("--output",  default="undef", help="output file name")

	parser.add_argument("--cloud",   default="undef",    choices=["aws", "az", "gcp", "oci"], help="cloud provider")

	parser.add_argument("--list",	 dest='LIST',	  action='store_true', default=False, help="list workbook/worksheet/csv ? (default: %(default)s)")
	parser.add_argument("--dump",	 dest='DUMP',	  action='store_true', default=False, help="dump workbook/worksheet/csv ? (default: %(default)s)")
	parser.add_argument("--verbose", dest='VERBOSE',  action='store_true', default=False, help="verbose output (default: %(default)s)")
	parser.add_argument("--version", dest='VERSION',  action='store_true', default=False, help="show version and exit (default: %(default)s)")

	parser.add_argument("--log",	 default="undef", help="log file name")

	parser.add_argument("--dbsave",  dest='DBSAVE',     action='store_true', default=False, help="store in db ? (default: %(default)s)")
	parser.add_argument("--dbname",  default="tags.db", help="db file name")
	parser.add_argument("--dbtype",  default="sqlite",  choices=["mysql", "sqlite"], help="db brand")

	### parser.set_defaults(VERSION=False)

	args = parser.parse_args()
	###________________________________________________________________________

	CLOUDNAME  = args.cloud
	OUTPUTFILE = args.output
	CSVNAME	   = args.csv
	LOGNAME	   = args.log
	XLSXNAME   = args.xlsx

	CLICMD	   = args.cmd
	CLIARG	   = args.arg
	FORMAT	   = args.format

	WSNAME	   = args.wsname

	DBSAVEFLAG = args.DBSAVE
	DBNAME	   = args.dbname
	DBTYPE	   = args.dbtype

	DUMPFLAG   = args.DUMP
	LISTFLAG   = args.LIST

	VERBFLAG   = args.VERBOSE
	VERSFLAG   = args.VERSION
	###________________________________________________________________________

	if VERSFLAG:
		myversion()
		exit()

	if VERBFLAG:
		print('')
		print("=== cloud  : " + CLOUDNAME)
		print("=== output : " + OUTPUTFILE)
		print("=== xlsx   : " + XLSXNAME)
		print("=== csv	: " + CSVNAME)
	###________________________________________________________________________

	if DBSAVEFLAG:
		print("=== dbname : " + DBNAME)
		print("=== dbtype : " + DBTYPE)
	###________________________________________________________________________

	if CSVNAME != "undef":
		check_good_file(CSVNAME)
		with open(CSVNAME, 'r') as csv_file:
			csv_reader = reader(csv_file)
			if DUMPFLAG:
				dump_csv(csv_reader)
			elif LISTFLAG:
				list_csv(csv_reader)
	###________________________________________________________________________

	if XLSXNAME != "undef":
		check_good_file(XLSXNAME)
		workbook = openpyxl.load_workbook(XLSXNAME)

		if VERBFLAG:
			print('')
			print("============================================================")
			### print(workbook.get_sheet_names())
			print("=== sheet names : %s" % (workbook.sheetnames))
			print("============================================================")

	###________________________________________________________________________

		if LISTFLAG:
			if WSNAME == "undef":
				for worksheet in workbook.worksheets:
					list_worksheet(worksheet)
			else:
				# worksheet = workbook.get_sheet_by_name(WSNAME)
				worksheet = workbook[WSNAME]
				list_worksheet(worksheet)

	###________________________________________________________________________

		if DUMPFLAG:
			if WSNAME == "undef":
				for worksheet in workbook.worksheets:
					dump_worksheet(worksheet)
			else:
				worksheet = workbook.get_sheet_by_name(WSNAME)
				dump_worksheet(worksheet)

###____________________________________________________________________________
###	command
###____________________________________________________________________________

	if CLICMD != "undef":
		if XLSXNAME != "undef":
			### workbook = openpyxl.load_workbook(XLSXNAME)
			print('')
			if VERBFLAG:
				print("=== command (%s) arg (%s) input (%s)" % (CLICMD, CLIARG, XLSXNAME))
			FORMAT = "cli"
			if WSNAME == "undef":
				for worksheet in workbook.worksheets:
					list_worksheet(worksheet)
			else:
				# worksheet = workbook.get_sheet_by_name(WSNAME)
				worksheet = workbook[WSNAME]
				list_worksheet(worksheet)
		elif CSVNAME != "undef":
			if VERBFLAG:
				print("=== command (%s) arg (%s) input (%s)" % (CLICMD, CLIARG, CSVNAME))
			with open(CSVNAME, 'r') as csv_file:
				csv_reader = reader(csv_file)
				list_csv(csv_reader)
		else:
			print(">>> missing input file")
	else:
		print(">>> no cli command to process")

###____________________________________________________________________________


### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 


##  __________________________________________________________________________
## |                                                                          |
## |  This software is free and open-source: you can redistribute it and/or   |
## |  modify it under the terms stated on the GNU General Public License      |
## |  as published by the Free Software Foundation, either version 3 of the   |
## |  License, or (at your option) any later version.                         |
## |                                                                          |
## |   This code is distributed in the hope that it will be useful,           |
## |   but WITHOUT ANY WARRANTY; without even the implied warranty of         |
## |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   |
## |   See the GNU General Public License for more details.                   |
## |                                                                          |
## |   You should have received a copy of the GNU General Public License      |
## |   along with this code.  If not, see <http://www.gnu.org/licenses/>,     |
## |   or write to the Free Software Foundation, Inc.,                        |
## |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.               |
## |__________________________________________________________________________|
##


### vi:nu ts=4
